package com.cityspark_urbanart.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
